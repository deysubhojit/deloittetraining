package com.deloitte.trg.service;

public enum AccountTypeEnum 
{
	Consumer,Commercial;
}
