package com.deloitte.trg.service;

public class CreditUnionException extends RuntimeException 
{
	private static final long serialVersionUID = -4332615558470169795L;
	private String message;
	public CreditUnionException() 
	{
	}
	public CreditUnionException(String message) 
	{
		super(message);
		this.message=message;
	}
	
	@Override
	public String getMessage() 
	{
		return this.message;
	}
}
