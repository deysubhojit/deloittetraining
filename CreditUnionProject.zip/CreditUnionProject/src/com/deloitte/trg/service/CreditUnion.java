package com.deloitte.trg.service;

import java.util.Arrays;

public class CreditUnion 
{
	private String creditUnionName,address;
	private Account[] a1=new Account[100];

	//constructors
	public CreditUnion() 
	{
	}
	public CreditUnion(String creditUnionName, String address) 
	{
		this.creditUnionName = creditUnionName;
		this.address = address;
	}

	//getters and setters
	public String getCreditUnionName() 
	{
		return creditUnionName;
	}
	public void setCreditUnionName(String creditUnionName) 
	{
		this.creditUnionName = creditUnionName;
	}
	public String getAddress() 
	{
		return address;
	}
	public void setAddress(String address) 
	{
		this.address = address;
	}
	public void setAccounts(Account[] a) 
	{
		for(int i=0;i<a.length;i++) 
		{
			if(a[i] instanceof MoneyMarket)
			{
				a1[i]=new MoneyMarket();
			}
			else if(a[i] instanceof CertificateOfDeposit)
			{
				a1[i]=new CertificateOfDeposit();
			}
		}
	}
	@Override
	public String toString() 
	{
		return "CreditUnion [creditUnionName=" + creditUnionName + ", address=" + address + ", a1="
				+ Arrays.toString(a1) + "]";
	}
}
