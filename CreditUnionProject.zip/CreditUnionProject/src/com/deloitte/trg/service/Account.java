package com.deloitte.trg.service;

public abstract class Account 
{
	private String owner,accType;
	private int ownId;
	private double balance;
	
	//constructors
	public Account() 
	{
	}
	public Account(int ownId,String owner, double balance,String accType) 
	{
		this.ownId=ownId;
		this.owner = owner;
		this.balance = balance;
		this.accType=accType;
	}
	
	//getters and setters
	public int getOwnId() 
	{
		return ownId;
	}
	public void setOwnId(int ownId) 
	{
		this.ownId = ownId;
	}
	public String getOwner() 
	{
		return owner;
	}
	public void setOwner(String owner) 
	{
		this.owner = owner;
	}
	public double getBalance() 
	{
		return balance;
	}
	public void setBalance(double balance) 
	{
		this.balance = balance;
	}
	public String getAccType() 
	{
		return accType;
	}
	public void setAccType(String accType)
	{
		this.accType = accType;
	}

}


