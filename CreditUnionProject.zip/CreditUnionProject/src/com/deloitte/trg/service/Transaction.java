package com.deloitte.trg.service;

public interface Transaction 
{
	void deposit(double balance);
	void withdraw(double balance) throws CreditUnionException;
	void transfer(Account a,double amount);
}
