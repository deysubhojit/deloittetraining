package com.deloitte.trg.service;

public class MoneyMarket extends Account 
{
	
	//constructors
	public MoneyMarket() 
	{
	}
	public MoneyMarket(int ownId,String name,double balance,String accType,AccountTypeEnum e) 
	{
		super(ownId,name,balance,accType);
		switch(e) 
		{
			case Consumer:new ConsumerType(balance);
			break;
			case Commercial:new CommercialType(balance);
			break;
		}
	}
	
}
	
